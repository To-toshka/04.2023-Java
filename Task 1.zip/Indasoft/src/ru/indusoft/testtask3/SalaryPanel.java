package ru.indusoft.testtask3;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;


public class SalaryPanel extends JPanel{

	private static final long serialVersionUID = 1L;
	
	private ConnectionDB connect;
	
	private SelectTableMode stm = new SelectTableMode();
	private JTable selectTable = new JTable(stm);
	private Choice departmentChoice = new Choice();
	private JLabel label = new JLabel	("Рассчитать повышение зарплаты:");
	private JLabel per = new JLabel ("%");
	private TextField percentTextField = new TextField("Введите процент повышения");
	private JButton callFunctionButton = new JButton("Рассчитать зарплату");
	
	
	public SalaryPanel(ConnectionDB connect) {
		this.connect = connect;
		setLayout (new FlowLayout(FlowLayout.CENTER,15,15));
	}
	
	public void init() {
		add(label);
		add(departmentChoice);
			departmentChoice.add("Административный отдел (id 1)");
			departmentChoice.add("Отдел разработки (id 2)");
			departmentChoice.add("Отдел продаж (id 3)");
			departmentChoice.add("Отдел обслуживания (id 4)");
		add(percentTextField);
		add (per);
		add(callFunctionButton);
			callFunctionButton.addActionListener(new CallButtonListener());
			
			callFunctionButton.getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("ENTER"), "RELEASED");			
			callFunctionButton.getActionMap().put("RELEASED", anAction);
		
		JScrollPane selectTableScrollPane = new JScrollPane(selectTable);
		
		stm.addData(connect);
		
		add(selectTableScrollPane);
			selectTableScrollPane.setPreferredSize(new Dimension (940,770));
	}
	
	public class CallButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent event) {
			
			Integer i;
			Integer j = 0;
						
			if (departmentChoice.getSelectedItem().equals("Административный отдел (id 1)")){
				i = 1;
			}else if (departmentChoice.getSelectedItem().equals("Отдел разработки (id 2)")){
				i = 2;
			}else if (departmentChoice.getSelectedItem().equals("Отдел продаж (id 3)")) {
				i = 3;
			}else if (departmentChoice.getSelectedItem().equals("Отдел обслуживания (id 4)")) {
				i = 4;
			}else {
				i = 0;
			}
			
			try {
				j = Integer.parseInt (percentTextField.getText());
			}catch (NumberFormatException nfe){
			      System.out.println("NumberFormatException: " + nfe.getMessage());
		    }
			
			if (j < 0) {
				j = -j;
			}else {
				j = j;
			}
			
		  			
			Connection connection = null;
	        String url = "jdbc:postgresql://127.0.0.1:5432/indusoft";
	        String name = "postgres";
	        String password = "1234";
	        try {
	            Class.forName("org.postgresql.Driver");
	            connection = DriverManager.getConnection(url, name, password);   
	            
	            CallableStatement callableStatement = connection.prepareCall(
	                    " { call update_salary_for_department(?,?) } ");
	            callableStatement.setInt(1, i);
	            callableStatement.setInt(2, j);
	            System.out.println(i+","+j);
	            callableStatement.execute();

	        } catch (Exception e) {
	        	e.printStackTrace();
	        } finally {
	            try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
	                }
			stm.addData(connect);
			repaint();
		}
	}

	
	Action anAction = new AbstractAction("Call Function") {  
        
		private static final long serialVersionUID = 1L;

		public void actionPerformed(ActionEvent e) {     
			Integer i;
			Integer j = 0;
						
			if (departmentChoice.getSelectedItem().equals("Административный отдел (id 1)")){
				i = 1;
			}else if (departmentChoice.getSelectedItem().equals("Отдел разработки (id 2)")){
				i = 2;
			}else if (departmentChoice.getSelectedItem().equals("Отдел продаж (id 3)")) {
				i = 3;
			}else if (departmentChoice.getSelectedItem().equals("Отдел обслуживания (id 4)")) {
				i = 4;
			}else {
				i = 0;
			}
			
			try {
				j = Integer.parseInt (percentTextField.getText());
			}catch (NumberFormatException nfe){
			      System.out.println("NumberFormatException: " + nfe.getMessage());
		    }
			
			if (j < 0) {
				j = -j;
			}else {
				j = j;
			}
		  			
			Connection connection = null;
	        String url = "jdbc:postgresql://127.0.0.1:5432/indusoft";
	        String name = "postgres";
	        String password = "12342";
	        try {
	            Class.forName("org.postgresql.Driver");
	            connection = DriverManager.getConnection(url, name, password);   
	            
	            CallableStatement callableStatement = connection.prepareCall(
	                    " { call update_salary_for_department(?,?) } ");
	            callableStatement.setInt(1, i);
	            callableStatement.setInt(2, j);
	            System.out.println(i+","+j);
	            callableStatement.execute();

	        } catch (Exception ex) {
	        	ex.printStackTrace();
	        } finally {
	            try {
					connection.close();
				} catch (SQLException ex) {
					ex.printStackTrace();
				}
	                }
			stm.addData(connect);
			repaint();
        }
    };
	
}
