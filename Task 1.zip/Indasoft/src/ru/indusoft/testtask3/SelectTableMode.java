package ru.indusoft.testtask3;

import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.sql.*;

public class SelectTableMode extends AbstractTableModel{

	private static final long serialVersionUID = 1L;
	
	private int columnCount = 5;
	private ArrayList<String []> dataArrayList;

	public SelectTableMode() {
		dataArrayList = (new ArrayList<String []>());
		for(int i=0; i<dataArrayList.size(); i++) {
			dataArrayList.add(new String[getColumnCount()]);
		}
	}
	
	@Override
	public int getRowCount() {
		return dataArrayList.size();
	}

	@Override
	public int getColumnCount() {
		return columnCount;
	}

	@Override
	public String getColumnName(int columnIndex) {
		switch(columnIndex) {
			case 0: return "id";
			case 1: return "department_id";
			case 2: return "name";
			case 3: return "salary";
			case 4: return "old_salary";
		}
		return "";
	} 

	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		String []rows = dataArrayList.get(rowIndex);
		return rows[columnIndex];
	}
	
	public void addData (String []row) {
		String []rowTable = new String [getColumnCount()];
		rowTable = row;
		dataArrayList.add(rowTable);
	}

	@Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
		
	}

	@Override
	public void addTableModelListener(TableModelListener l) {
		
	}

	@Override
	public void removeTableModelListener(TableModelListener l) {
		
	}
	
	public void addData(ConnectionDB connect) {
		ResultSet result = connect.resultSetQuery ("SELECT id, department_id, name, "
				+ "salary, old_salary FROM employee ORDER BY id");
		dataArrayList.clear();
		try {
			while (result.next()) {
				String []row = {
						result.getString("id"),
						result.getString("department_id"),
						result.getString("name"),
						result.getString("salary"),
						result.getString("old_salary")
				};
				addData(row);
			}
			result.close ();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
