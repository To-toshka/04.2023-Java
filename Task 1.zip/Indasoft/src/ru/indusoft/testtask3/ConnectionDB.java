package ru.indusoft.testtask3;

import java.sql.*;
import java.util.Properties;

public class ConnectionDB {
	private String host;
	private String dataDb;
	private String root;
	private String password;
	private String url;
	
	private Properties properties = new Properties ();
	private Connection connect;
	
	public ConnectionDB (String host, String root, String password) {
		this.host = host;
		this.root = root;
		this.password = password;
	}
	
	public ConnectionDB (String url, Properties properties) {
		this.url = url;
		this.properties = properties;
	}
	
	public void setNameDataBasses (String dataDb) {
		this.dataDb = dataDb;
	}
	
	public void initProperties() {
		this.url = "jdbc:postgresql://" + this.host + "/" + this.dataDb;
		
		properties.setProperty("user", this.root);
		properties.setProperty("password", this.password);
		properties.setProperty("useUnicode", "true");
		properties.setProperty("characterEncoding", "UTF-8");
	}
	
	public int init() {
		if (connect !=null) {
			try {
				connect.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		try {
			Class.forName("org.postgresql.Driver");
    		connect = DriverManager.getConnection(url, properties);
    	} catch (ClassNotFoundException e) {
    		e.printStackTrace();
    		return -1;
    	} catch (SQLException e) {
    		e.printStackTrace();
    		return -1;			
		}
		return 0;
	}
	
	public ResultSet resultSetQuery (String query) {
		try {
			Statement stmt = connect.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			return rs;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void SQLquery (String query) {
		try {
			Statement stmt = connect.createStatement();
			stmt.executeUpdate(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	
	public Connection getConnect() {
		return connect;
	}

}
