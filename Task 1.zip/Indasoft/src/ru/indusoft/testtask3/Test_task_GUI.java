package ru.indusoft.testtask3;

import java.awt.*;
import javax.swing.*;

public class Test_task_GUI {
		
	public static void main(String arg[]) {
		
		ConnectionDB connect = new ConnectionDB("127.0.0.1:5432","postgres","1234");
		connect.setNameDataBasses ("indusoft");
		connect.initProperties();
		connect.init();
		
		JFrame oknoFrame = new JFrame ("Зарплата сотрудников");
		oknoFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		oknoFrame.setSize(1000, 900);
		oknoFrame.setResizable(false);
		oknoFrame.setLocationRelativeTo(null);
		oknoFrame.setLayout(new BorderLayout());
		
		SalaryPanel salaryPanel = new SalaryPanel(connect);
		salaryPanel.init();
		
		oknoFrame.add(salaryPanel, BorderLayout.CENTER);
	
		oknoFrame.setVisible(true);		
	}
	
}


