/**
 * 
 */
/**
 * @author Evgen
 *
 */
module Indasoft {
	requires java.desktop;
}